def summa(x, y):
    return x + y